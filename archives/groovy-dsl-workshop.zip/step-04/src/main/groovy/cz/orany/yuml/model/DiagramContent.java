package cz.orany.yuml.model;

public interface DiagramContent { }
