package cz.orany.yuml.model;

public class DiagramKeywords {

    public enum From { FROM }

    public static final From from = From.FROM;

}
