package cz.orany.yuml.model;

public interface Type extends DiagramContentDefinition {
    String getName();
}
