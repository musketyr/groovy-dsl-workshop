package cz.orany.yuml.model;

public interface DiagramContentDefinition { }
