package cz.orany.yuml.model;

public interface Note extends DiagramContentDefinition {
    String getText();

    String getColor();
}
