package cz.orany.yuml.model;

import java.util.Map;

public interface DiagramHelper {

    Map<String, Object> getMetadata();

}
