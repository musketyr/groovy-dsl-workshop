package cz.orany.yuml.model;

public enum RelationshipType {
    ASSOCIATION, AGGREGATION, COMPOSITION, INHERITANCE;
}
