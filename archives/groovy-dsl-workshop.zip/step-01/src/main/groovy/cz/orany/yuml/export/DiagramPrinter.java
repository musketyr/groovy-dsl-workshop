package cz.orany.yuml.export;

import cz.orany.yuml.model.Diagram;

public interface DiagramPrinter {

    String print(Diagram diagram);

}
